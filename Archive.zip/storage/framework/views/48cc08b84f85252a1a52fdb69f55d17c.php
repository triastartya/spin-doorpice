<?php $__env->startSection('title', 'Karyawan'); ?>
<?php $__env->startSection('content'); ?>
<div x-data="{ addOpen: false, editOpen: false, edit: { id: '', nik: '', name: '', department: '', email: '', active: true } }">
    <div class="flex flex-wrap items-end justify-between gap-4">
        <div><h1 class="page-title">Karyawan</h1><p class="page-sub">Kelola data karyawan yang berlaku untuk seluruh acara.</p></div>
        <div class="flex flex-wrap gap-3"><a href="<?php echo e(url('admin/employees-import')); ?>" class="btn-ghost"><svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v12m0 0 4-4m-4 4-4-4M5 20h14"/></svg>Import Excel</a><a href="<?php echo e(url('admin/employees-template')); ?>" class="btn-ghost">Unduh Template</a><button type="button" @click="addOpen=true" class="btn-primary"><svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>Tambah Karyawan</button></div>
    </div>

    <div class="card mt-6 p-5">
        <form method="get" class="flex flex-col gap-3 sm:flex-row">
            <div class="relative flex-1"><svg class="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21 21-4.35-4.35m2.35-5.65a8 8 0 1 1-16 0 8 8 0 0 1 16 0Z"/></svg><input name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari NIK, nama, departemen, atau email..." class="input pl-12"></div>
            <button class="btn-primary sm:px-7">Cari</button>
            <?php if(request('q')): ?><a href="<?php echo e(url('admin/employees')); ?>" class="btn-ghost">Reset</a><?php endif; ?>
        </form>
        <div class="mt-4 flex flex-wrap gap-6 border-t border-slate-100 pt-4 text-sm text-slate-500"><span><strong class="text-slate-800"><?php echo e($employees->total()); ?></strong> karyawan terdaftar</span><span><strong class="text-emerald-600"><?php echo e($employees->getCollection()->where('is_active', true)->count()); ?></strong> aktif di halaman ini</span><span><strong class="text-slate-500"><?php echo e($employees->getCollection()->where('is_active', false)->count()); ?></strong> nonaktif di halaman ini</span></div>
    </div>

    <div class="table-wrap mt-6">
        <table class="min-w-[860px]">
            <thead><tr><th class="w-14">#</th><th>Karyawan</th><th>NIK</th><th>Departemen</th><th>Email</th><th>Status</th><th class="text-right">Aksi</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="font-mono text-xs text-slate-400"><?php echo e(($employees->firstItem() ?? 0) + $loop->iteration - 1); ?></td>
                    <td><div class="flex items-center gap-3"><div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-sm font-bold text-blue-700"><?php echo e(collect(explode(' ', $employee->name))->take(2)->map(fn($n) => mb_substr($n,0,1))->implode('')); ?></div><div><p class="font-semibold text-slate-800"><?php echo e($employee->name); ?></p><p class="text-xs text-slate-400">ID #<?php echo e($employee->id); ?></p></div></div></td>
                    <td class="font-mono font-medium text-slate-700"><?php echo e($employee->nik); ?></td>
                    <td><?php echo e($employee->department ?: '—'); ?></td>
                    <td class="text-slate-500"><?php echo e($employee->email ?: '—'); ?></td>
                    <td><span class="badge <?php echo e($employee->is_active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'); ?>"><span class="mr-1.5 h-1.5 w-1.5 rounded-full <?php echo e($employee->is_active ? 'bg-emerald-500' : 'bg-slate-400'); ?>"></span><?php echo e($employee->is_active ? 'Aktif' : 'Nonaktif'); ?></span></td>
                    <td><div class="flex justify-end gap-2"><button type="button" @click="edit={id:'<?php echo e($employee->id); ?>',nik:<?php echo \Illuminate\Support\Js::from($employee->nik)->toHtml() ?>,name:<?php echo \Illuminate\Support\Js::from($employee->name)->toHtml() ?>,department:<?php echo \Illuminate\Support\Js::from($employee->department)->toHtml() ?>,email:<?php echo \Illuminate\Support\Js::from($employee->email)->toHtml() ?>,active:<?php echo e($employee->is_active ? 'true' : 'false'); ?>};editOpen=true" class="btn-ghost px-3 py-2">Edit</button><form method="post" action="<?php echo e(url('admin/employees/'.$employee->id)); ?>" onsubmit="return confirm('Hapus data <?php echo e(addslashes($employee->name)); ?>?')"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?><button class="btn-danger px-3 py-2">Hapus</button></form></div></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"><div class="empty-state"><div class="flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-50 text-xl text-blue-600">♙</div><p class="font-semibold text-slate-700"><?php echo e(request('q') ? 'Karyawan tidak ditemukan' : 'Belum ada data karyawan'); ?></p><p class="text-sm"><?php echo e(request('q') ? 'Coba gunakan kata kunci lain.' : 'Mulai dengan import Excel atau tambah manual.'); ?></p></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-6"><?php echo e($employees->withQueryString()->links()); ?></div>

    <div x-show="addOpen" x-cloak @keydown.escape.window="addOpen=false" class="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div x-show="addOpen" x-transition.opacity @click="addOpen=false" class="absolute inset-0 bg-slate-900/50 backdrop-blur-sm"></div>
        <div x-show="addOpen" x-transition class="relative w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl">
            <div class="flex items-center justify-between border-b border-slate-100 px-6 py-5"><div><h2 class="text-xl font-bold text-slate-800">Tambah Karyawan</h2><p class="mt-1 text-sm text-slate-500">Masukkan data karyawan baru.</p></div><button @click="addOpen=false" class="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100">✕</button></div>
            <form method="post" action="<?php echo e(url('admin/employees')); ?>" class="space-y-4 p-6"><?php echo csrf_field(); ?>
                <div class="grid gap-4 sm:grid-cols-2"><label class="label">NIK<input name="nik" required placeholder="Nomor induk" class="input mt-1"></label><label class="label">Departemen<input name="department" placeholder="Contoh: IT" class="input mt-1"></label></div>
                <label class="label">Nama lengkap<input name="name" required placeholder="Nama karyawan" class="input mt-1"></label>
                <label class="label">Email <span class="font-normal text-slate-400">(opsional)</span><input name="email" type="email" placeholder="nama@perusahaan.com" class="input mt-1"></label>
                <label class="flex items-center gap-3 rounded-xl bg-slate-50 p-4 text-sm font-medium text-slate-700"><input type="checkbox" name="is_active" value="1" checked class="h-4 w-4 accent-blue-600">Karyawan aktif dan dapat mengikuti acara</label>
                <div class="flex justify-end gap-3 border-t border-slate-100 pt-4"><button type="button" @click="addOpen=false" class="btn-ghost">Batal</button><button class="btn-primary">Tambah Karyawan</button></div>
            </form>
        </div>
    </div>

    <div x-show="editOpen" x-cloak @keydown.escape.window="editOpen=false" class="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div x-show="editOpen" x-transition.opacity @click="editOpen=false" class="absolute inset-0 bg-slate-900/50 backdrop-blur-sm"></div>
        <div x-show="editOpen" x-transition class="relative w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl">
            <div class="flex items-center justify-between border-b border-slate-100 px-6 py-5"><div><h2 class="text-xl font-bold text-slate-800">Edit Karyawan</h2><p class="mt-1 text-sm text-slate-500">Perbarui data karyawan.</p></div><button @click="editOpen=false" class="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100">✕</button></div>
            <form method="post" :action="'/admin/employees/'+edit.id" class="space-y-4 p-6"><?php echo csrf_field(); ?> <?php echo method_field('put'); ?><input type="hidden" name="is_active" value="0">
                <div class="grid gap-4 sm:grid-cols-2"><label class="label">NIK<input name="nik" x-model="edit.nik" required class="input mt-1"></label><label class="label">Departemen<input name="department" x-model="edit.department" class="input mt-1"></label></div>
                <label class="label">Nama lengkap<input name="name" x-model="edit.name" required class="input mt-1"></label>
                <label class="label">Email<input name="email" type="email" x-model="edit.email" class="input mt-1"></label>
                <label class="flex items-center gap-3 rounded-xl bg-slate-50 p-4 text-sm font-medium text-slate-700"><input type="checkbox" name="is_active" value="1" x-model="edit.active" class="h-4 w-4 accent-blue-600">Karyawan aktif</label>
                <div class="flex justify-end gap-3 border-t border-slate-100 pt-4"><button type="button" @click="editOpen=false" class="btn-ghost">Batal</button><button class="btn-primary">Simpan Perubahan</button></div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/triastartya/WORK/spin/resources/views/admin/employees.blade.php ENDPATH**/ ?>