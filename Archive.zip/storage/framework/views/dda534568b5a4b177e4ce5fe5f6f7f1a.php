<?php $__env->startSection('title', 'Penyerahan Hadiah'); ?>
<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-2xl" x-data="handover(<?php echo e($winner && $winner->status === 'menang' ? 'true' : 'false'); ?>)">
    <h1 class="page-title">Penyerahan Hadiah</h1>
    <p class="page-sub">Input atau scan kode kupon pemenang.</p>
    <form method="get" class="mt-6 flex flex-col gap-3 sm:flex-row"><input name="code" value="<?php echo e($code); ?>" required placeholder="ABC123" autofocus class="input flex-1 font-mono text-lg uppercase"><button class="btn-primary sm:px-8">Cari</button></form>

    <?php if($code && !$winner): ?><div class="alert-error mt-8">Kupon <strong class="font-mono"><?php echo e($code); ?></strong> tidak ditemukan atau bukan pemenang.</div><?php endif; ?>

    <?php if($winner): ?>
    <div class="card mt-8 p-7">
        <div class="flex flex-wrap items-center justify-between gap-4">
            <div>
                <p class="font-mono text-3xl font-black text-emerald-600"><?php echo e($winner->coupon->code); ?></p>
                <p class="mt-3 text-xl font-bold text-slate-800"><?php echo e($winner->coupon->employee->name); ?></p>
                <p class="text-slate-500"><?php echo e($winner->coupon->employee->nik); ?> · <?php echo e($winner->coupon->employee->department); ?></p>
            </div>
            <div class="text-right">
                <?php if($winner->prize->image_path): ?><img src="<?php echo e(asset($winner->prize->image_path)); ?>" class="ml-auto h-24 w-24 rounded-xl object-cover" alt="<?php echo e($winner->prize->name); ?>"><?php endif; ?>
                <p class="mt-2 text-sm text-slate-500">Hadiah</p>
                <p class="text-lg font-bold text-slate-800"><?php echo e($winner->prize->name); ?></p>
                <span class="badge mt-3 <?php echo e($winner->status === 'menang' ? 'bg-amber-50 text-amber-700' : ($winner->status === 'diserahkan' ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700')); ?>"><?php echo e(ucfirst($winner->status)); ?></span>
            </div>
        </div>

        <?php if($winner->photo_path): ?>
        <div class="mt-6 rounded-2xl border border-slate-200 bg-slate-50 p-4"><p class="mb-3 text-xs font-bold uppercase tracking-widest text-slate-400">Foto bukti pengambilan</p><img src="<?php echo e(asset($winner->photo_path)); ?>" alt="Bukti pengambilan" class="max-h-64 rounded-xl"></div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(url('operator/kupon/handover')); ?>" enctype="multipart/form-data" class="mt-7 space-y-4"><?php echo csrf_field(); ?>
            <input type="hidden" name="code" value="<?php echo e($winner->coupon->code); ?>">
            <input type="hidden" name="photo_data" :value="photoData">
            <template x-if="camOpen || photoData">
                <div>
                    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-black"><video x-ref="video" x-show="camOpen" autoplay playsinline class="aspect-video w-full object-cover"></video><canvas x-ref="canvas" class="hidden"></canvas><img x-show="!camOpen && photoData" :src="photoData" alt="Pratinjau foto" class="aspect-video w-full object-contain"></div>
                    <div class="mt-3 flex flex-wrap gap-3">
                        <button type="button" x-show="camOpen" @click="capture()" class="btn-primary">📷 Ambil Foto</button>
                        <button type="button" x-show="camOpen" @click="stop()" class="btn-ghost">Tutup Kamera</button>
                        <button type="button" x-show="!camOpen && photoData" @click="start()" class="btn-ghost">Ulangi Foto</button>
                        <button type="button" x-show="!camOpen && photoData" @click="photoData=''" class="btn-danger">Hapus Foto</button>
                    </div>
                </div>
            </template>
            <button type="button" x-show="!camOpen && !photoData" @click="start()" <?php echo e($winner->status !== 'menang' ? 'disabled' : ''); ?> class="btn-ghost w-full">📷 Ambil Foto Bukti <span class="font-normal text-slate-400">(opsional)</span></button>
            <button <?php echo e($winner->status !== 'menang' ? 'disabled' : ''); ?> class="btn-success w-full py-3.5">Serahkan Hadiah</button>
        </form>

        <?php if($winner->status !== 'dibatalkan'): ?>
        <form method="post" action="<?php echo e(url('operator/kupon/'.$winner->id.'/cancel')); ?>" class="mt-4 flex flex-col gap-3 sm:flex-row"><?php echo csrf_field(); ?>
            <input name="reason" required placeholder="Alasan pembatalan (wajib)" class="input flex-1">
            <button class="btn-danger">Batalkan</button>
        </form>
        <?php endif; ?>

        <?php if($winner->taken_at): ?><p class="mt-4 text-sm text-slate-500">Diserahkan <?php echo e($winner->taken_at->format('d M Y H:i')); ?></p><?php endif; ?>
        <?php if($winner->cancel_reason): ?><p class="mt-4 text-sm text-red-600">Dibatalkan: <?php echo e($winner->cancel_reason); ?></p><?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<script>
function handover(){return{camOpen:false,photoData:'',stream:null,async start(){this.camOpen=true;this.photoData='';try{this.stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment',width:{ideal:1280},height:{ideal:720}},audio:false});await this.$nextTick();this.$refs.video.srcObject=this.stream}catch(e){this.camOpen=false;alert('Kamera tidak dapat diakses. Pastikan izin kamera diberikan dan halaman dibuka via HTTPS/localhost.')}},stop(){this.stream?.getTracks().forEach(t=>t.stop());this.stream=null;this.camOpen=false},capture(){const v=this.$refs.video,c=this.$refs.canvas;c.width=v.videoWidth;c.height=v.videoHeight;c.getContext('2d').drawImage(v,0,0);this.photoData=c.toDataURL('image/jpeg',0.85);this.stop()},destroy(){this.stop()}}}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/triastartya/WORK/spin/resources/views/operator/coupon.blade.php ENDPATH**/ ?>